package Project.Student_Management_System;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Student {

	@Id
	@Column(name="rollid")
	private int rollid;
	private String name;
	private String address;
	
	public Student() {
		super();
	}
	public Student(int rollid, String name, String address, String gender, String birthdate) {
		super();
		this.rollid = rollid;
		this.name = name;
		this.address = address;
		
	}
	public int getRollid() {
		return rollid;
	}
	public void setRollid(int rollid) {
		this.rollid = rollid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	@Override
	public String toString() {
		return "Student [rollid=" + rollid + ", name=" + name + ", address=" + address + "]";
	}
  
	
	




}
