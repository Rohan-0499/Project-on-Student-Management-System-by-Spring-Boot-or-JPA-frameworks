package Project.Student_Management_System;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class StudentControllerApp {
	@RequestMapping("application")
	public String getData() {
		
		
		return"page";
	}
	@RequestMapping("application2")
	
		public String handleForm(){
		return"Page1";
	}

}
