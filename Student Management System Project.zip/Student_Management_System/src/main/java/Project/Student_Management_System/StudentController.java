package Project.Student_Management_System;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class StudentController {

	@Autowired
	SessionFactory factory;
	@GetMapping("allstudent")
	
	List<Student> GetAll(){
		
		Session  session = factory.openSession();
		
		List <Student> li = session.createCriteria(Student.class).list();
		return li;
	}	
	@GetMapping("onlystudent/{id}")
	public Student getStudent(@PathVariable int id) {
		Session session = factory.openSession();
		Student employee =  session.load(Student.class,  id);
		return employee;
	}
	@PostMapping("poststudent")
	public List<Student> addStudent(@RequestBody Student employee){
		Session  session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(employee);
		tx.commit();
		List<Student> list = GetAll();
		return list;
	}
	@PutMapping("putstudent")
	public List<Student> updateStudent(@RequestBody Student client){
		Session  session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.saveOrUpdate(client);
		tx.commit();
		List<Student> list = GetAll();
		return list;
	}
	@DeleteMapping("removestudent/{id}")
	public List<Student> deleteStudent(@PathVariable int id){
		Session session = factory.openSession();
		Student student =session.load(Student.class, id);
		Transaction tx = session.beginTransaction();
		session.delete(student);
		tx.commit();
		List<Student> list = GetAll();
		
		
		return list;
	}
	

}
